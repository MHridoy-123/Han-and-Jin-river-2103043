from pathlib import Path
import warnings, json, zipfile
warnings.filterwarnings('ignore')
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, precision_score, recall_score, f1_score, accuracy_score, average_precision_score
from xgboost import XGBRegressor, DMatrix

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'Reanalysis_Outputs'; TAB=OUT/'tables'; FIG=OUT/'figures'; DATA=OUT/'processed'; MOD=OUT/'models'
for d in [OUT,TAB,FIG,DATA,MOD]: d.mkdir(parents=True,exist_ok=True)
FILES={'Han River':ROOT/'Dataset_WQ_Han_River.csv','Jin River':ROOT/'Dataset_WQ_Jin_River.csv'}
COL={'WT':'wt','pH':'ph','DO':'do','CODMn':'cod_mn','NH3-N':'nh3_n','TP':'tp','TN':'tn','EC':'ec','Turbidity':'turbidity'}
BASE=list(COL.values())
HORIZONS=[1,3,6,12,18]; LAGS=[1,2,3,6,12,18]; ROLLS=[6,12]

def load_one(path,river):
 d=pd.read_csv(path); d=d.rename(columns={d.columns[0]:'date',**COL}); d['date']=pd.to_datetime(d['date']); d=d.sort_values('date').drop_duplicates('date'); d['river']=river; return d
raw={r:load_one(f,r) for r,f in FILES.items()}
# Audit
au=[]; negatives=[]
for r,d in raw.items():
 full=pd.date_range(d.date.min(),d.date.max(),freq='4h'); delta=d.date.diff().dt.total_seconds()/3600
 au.append({'river':r,'observed_rows':len(d),'expected_4h_rows':len(full),'missing_timestamps':len(full)-d.date.nunique(),'completeness_pct':100*d.date.nunique()/len(full),'duplicate_timestamps':int(d.date.duplicated().sum()),'max_gap_hours':float(delta.max()),'non_4h_intervals':int((delta.dropna()!=4).sum())})
 for v in BASE:
  x=d[d[v]<0]
  for _,row in x.iterrows(): negatives.append({'river':r,'date':row.date,'variable':v,'value':row[v]})
pd.DataFrame(au).to_csv(TAB/'R1_timestamp_audit.csv',index=False)
pd.DataFrame(negatives).to_csv(TAB/'R2_negative_value_audit.csv',index=False)

# Regularization and causal imputation. Target eligibility remains only true original observations.
def regularize(d, clean_neg=True):
 x=d.set_index('date').copy(); full=pd.date_range(x.index.min(),x.index.max(),freq='4h'); x=x.reindex(full); x.index.name='date';
 x['river']=d.river.iloc[0]; x['observed_row']=x['do'].notna()
 for v in BASE: x[f'{v}_observed']=x[v].notna()
 if clean_neg:
  for v in ['cod_mn','tp','turbidity']: x.loc[x[v]<0,v]=np.nan
 # causal: max 24h forward fill, then training-derived month-hour median, then global training median
 idx=x.index; trainmask=idx.year<=2023
 for v in BASE:
  original=x[v].copy()
  ff=original.ffill(limit=6)
  tr=pd.DataFrame({'val':original[trainmask],'month':idx[trainmask].month,'hour':idx[trainmask].hour})
  med=tr.groupby(['month','hour']).val.median(); glob=tr.val.median()
  keys=list(zip(idx.month,idx.hour)); fallback=np.array([med.get(k,glob) for k in keys],dtype=float)
  x[v]=ff.fillna(pd.Series(fallback,index=idx)).fillna(glob)
  x[f'{v}_imputed']=original.isna()
 return x.reset_index()

regsets={}
for variant,clean in [('regularized_raw',False),('regularized_clean',True)]:
 regsets[variant]={r:regularize(d,clean) for r,d in raw.items()}
 pd.concat(regsets[variant].values()).to_csv(DATA/f'{variant}_4h.csv',index=False)

# Features
def features(df,h):
 z=df.copy().sort_values('date').reset_index(drop=True)
 z['hour']=z.date.dt.hour; z['month']=z.date.dt.month; z['doy']=z.date.dt.dayofyear
 z['sin_hour']=np.sin(2*np.pi*z.hour/24); z['cos_hour']=np.cos(2*np.pi*z.hour/24)
 z['sin_doy']=np.sin(2*np.pi*z.doy/366); z['cos_doy']=np.cos(2*np.pi*z.doy/366)
 z['wt_do_interaction']=z.wt*z.do; z['ph_do_interaction']=z.ph*z.do
 z['tn_tp_ratio']=z.tn/z.tp.where(z.tp>0,np.nan); z['nh3n_wt_interaction']=z.nh3_n*z.wt
 z['turbidity_codmn_interaction']=z.turbidity*z.cod_mn; z['ec_turbidity_interaction']=z.ec*z.turbidity
 for v in BASE:
  for lg in LAGS: z[f'{v}_lag{lg}']=z[v].shift(lg)
  for w in ROLLS:
   z[f'{v}_rollmean_{w}']=z[v].rolling(w).mean(); z[f'{v}_rollsd_{w}']=z[v].rolling(w).std()
 z['target']=z.do.shift(-h); z['target_date']=z.date.shift(-h); z['target_observed']=z.do_observed.shift(-h).fillna(False)
 # seasonal naive: last available same phase, recursively for horizons > 6
 back=max(0, int(np.ceil(h/6))*6-h)
 z['seasonal_naive']=z.do.shift(back) if back>0 else z.do
 z['horizon_steps']=h; z['horizon_hours']=h*4; z['year']=z.date.dt.year
 z=z.replace([np.inf,-np.inf],np.nan)
 return z

# metrics
def metrics(y,p):
 y=np.asarray(y); p=np.asarray(p); ok=np.isfinite(y)&np.isfinite(p); y=y[ok];p=p[ok]
 return {'RMSE':np.sqrt(np.mean((y-p)**2)),'MAE':np.mean(np.abs(y-p)),'MAPE':np.mean(np.abs((y-p)/np.where(y==0,np.nan,y)))*100,'R2':r2_score(y,p),'NSE':1-np.sum((y-p)**2)/np.sum((y-y.mean())**2),'Bias':np.mean(p-y)}
def boot_ci(y,p,B=100,block=6,seed=2026):
 y=np.asarray(y);p=np.asarray(p);n=len(y);rng=np.random.default_rng(seed); vals=[]
 starts=np.arange(0,n,block); blocks=[np.arange(s,min(s+block,n)) for s in starts]
 for _ in range(B):
  ids=np.concatenate([blocks[i] for i in rng.integers(0,len(blocks),len(blocks))])[:n]
  vals.append(np.sqrt(np.mean((y[ids]-p[ids])**2)))
 return np.percentile(vals,[2.5,97.5])

results=[]; preds=[]; fitted={}; feature_names={}
for variant,rivers in regsets.items():
 for river,df in rivers.items():
  run_horizons = HORIZONS if variant == 'regularized_clean' else [6]
  for h in run_horizons:
   z=features(df,h)
   exclude=['date','river','observed_row','target','target_date','target_observed','seasonal_naive','horizon_steps','horizon_hours','year']+[c for c in z if c.endswith('_observed') or c.endswith('_imputed')]
   feats=[c for c in z.columns if c not in exclude and pd.api.types.is_numeric_dtype(z[c])]
   z=z.dropna(subset=feats+['target']); z=z[z.target_observed]
   train=z[z.year<=2023]; test=z[z.year>=2024]
   Xtr=train[feats]; ytr=train.target; Xte=test[feats]; yte=test.target
   # baselines
   model_preds={'Persistence':test.do.values,'Seasonal persistence':test.seasonal_naive.values}
   ar_feats=[c for c in feats if c.startswith('do_lag')]+['do','do_rollmean_6','do_rollsd_6','do_rollmean_12','do_rollsd_12','sin_hour','cos_hour','sin_doy','cos_doy']
   ar=Ridge(alpha=1.0).fit(train[ar_feats],ytr); model_preds['Autoregressive ridge']=ar.predict(test[ar_feats])
   lm=LinearRegression().fit(Xtr,ytr); model_preds['Linear regression']=lm.predict(Xte)
   rf=RandomForestRegressor(n_estimators=100,max_features='sqrt',min_samples_leaf=5,random_state=2026,n_jobs=-1).fit(Xtr,ytr); model_preds['Random forest']=rf.predict(Xte)
   xgb=XGBRegressor(n_estimators=200,learning_rate=.03,max_depth=5,subsample=.85,colsample_bytree=.85,min_child_weight=3,objective='reg:squarederror',random_state=2026,n_jobs=2,base_score=float(ytr.mean())).fit(Xtr,ytr)
   model_preds['XGBoost']=xgb.predict(Xte)
   if variant=='regularized_clean' and h==6:
    fitted[river]=xgb; feature_names[river]=feats
   for name,pr in model_preds.items():
    met=metrics(yte,pr); lo,hi=boot_ci(yte.values,pr)
    results.append({'variant':variant,'river':river,'horizon_hours':h*4,'model':name,**met,'RMSE_CI_low':lo,'RMSE_CI_high':hi,'n_test':len(yte)})
    pp=pd.DataFrame({'variant':variant,'river':river,'horizon_hours':h*4,'model':name,'origin_date':test.date.values,'target_date':test.target_date.values,'observed':yte.values,'predicted':pr})
    preds.append(pp)
res=pd.DataFrame(results); pred=pd.concat(preds,ignore_index=True)
res.to_csv(TAB/'R3_full_model_performance_regularized_sensitivity.csv',index=False)
pred.to_csv(TAB/'R4_all_test_predictions.csv',index=False)
# Negative sensitivity deltas
pivot=res.pivot_table(index=['river','horizon_hours','model'],columns='variant',values=['RMSE','MAE','R2']).reset_index()
pivot.columns=['_'.join([str(x) for x in col if x]) for col in pivot.columns]
for m in ['RMSE','MAE','R2']:
 pivot[f'{m}_clean_minus_raw']=pivot[f'{m}_regularized_clean']-pivot[f'{m}_regularized_raw']
pivot.to_csv(TAB/'R5_negative_cleaning_sensitivity.csv',index=False)

# Unified SHAP native contributions on same clean 24h XGB and same test rows
shap_imp=[]
for river,model in fitted.items():
 df=regsets['regularized_clean'][river]; z=features(df,6); feats=feature_names[river]
 z=z.dropna(subset=feats+['target']); test=z[(z.year>=2024)&z.target_observed]
 sample=test.sample(n=min(700,len(test)),random_state=2026); X=sample[feats]
 contrib=model.get_booster().predict(DMatrix(X,feature_names=feats),pred_contribs=True); sv=contrib[:,:-1]
 imp=pd.DataFrame({'river':river,'feature':feats,'mean_abs_shap':np.abs(sv).mean(0)}).sort_values('mean_abs_shap',ascending=False); shap_imp.append(imp)
 safe=river.replace(' ','_'); imp.to_csv(TAB/f'R6_SHAP_importance_{safe}_24h.csv',index=False)
 # bar
 top=imp.head(25).iloc[::-1]; fig,ax=plt.subplots(figsize=(8,7)); ax.barh(top.feature,top.mean_abs_shap,color='#2c7fb8');ax.set_xlabel('Mean |SHAP value|');ax.set_title(f'Unified XGBoost SHAP importance: {river} | 24 h');fig.tight_layout();fig.savefig(FIG/f'R6_SHAP_bar_{safe}_24h.png',dpi=400,bbox_inches='tight');plt.close(fig)
 # beeswarm-like
 topn=imp.head(20).feature.tolist()[::-1]; fig,ax=plt.subplots(figsize=(9,7)); rng=np.random.default_rng(2026)
 for yi,f in enumerate(topn):
  j=feats.index(f); val=X[f].values; lo,hi=np.nanpercentile(val,[1,99]); color=np.clip((val-lo)/(hi-lo+1e-12),0,1); ax.scatter(sv[:,j],np.full(len(val),yi)+rng.normal(0,.07,len(val)),c=color,cmap='coolwarm',s=9,alpha=.65,edgecolors='none')
 ax.axvline(0,color='grey',lw=.8);ax.set_yticks(range(len(topn)));ax.set_yticklabels(topn);ax.set_xlabel('SHAP value');ax.set_title(f'Unified SHAP summary: {river} | 24 h');fig.tight_layout();fig.savefig(FIG/f'R7_SHAP_beeswarm_{safe}_24h.png',dpi=400,bbox_inches='tight');plt.close(fig)
pd.concat(shap_imp).to_csv(TAB/'R6_SHAP_importance_all_rivers_24h.csv',index=False)
# authoritative 24h XGB metrics
res[(res.variant=='regularized_clean')&(res.horizon_hours==24)&(res.model=='XGBoost')].to_csv(TAB/'R7_unified_XGBoost_SHAP_metrics_24h.csv',index=False)

# Threshold sensitivity all clean predictions; point + episode
cleanpred=pred[pred.variant=='regularized_clean'].copy(); rows=[]; eps=[]
for (river,h,model),g in cleanpred.groupby(['river','horizon_hours','model']):
 g=g.sort_values('target_date').copy()
 for th in [6,5,4]:
  obs=(g.observed<th).astype(int); pp=(g.predicted<th).astype(int)
  positives=int(obs.sum())
  rows.append({'river':river,'horizon_hours':h,'model':model,'threshold_mg_L':th,'n':len(g),'observed_positive_points':positives,'predicted_positive_points':int(pp.sum()),'accuracy':accuracy_score(obs,pp),'precision':precision_score(obs,pp,zero_division=0),'recall':recall_score(obs,pp,zero_division=0),'F1':f1_score(obs,pp,zero_division=0),'PR_AUC':average_precision_score(obs,-g.predicted) if positives>0 else np.nan})
  # episodes among target timestamps, consecutive 4h positives
  gg=g.assign(obs_event=obs.values,pred_event=pp.values).sort_values('target_date').reset_index(drop=True)
  pos=gg[gg.obs_event==1].copy(); episodes=[]
  if len(pos):
   grp=((pos.target_date.diff().dt.total_seconds().div(3600).fillna(4)>4)).cumsum()
   for _,e in pos.groupby(grp): episodes.append((e.target_date.min(),e.target_date.max()))
  detected=0; leads=[]
  for s,e in episodes:
   cand=gg[(gg.target_date>=s)&(gg.target_date<=e)&(gg.pred_event==1)]
   if len(cand): detected+=1; leads.append((s-cand.origin_date.min()).total_seconds()/3600)
  eps.append({'river':river,'horizon_hours':h,'model':model,'threshold_mg_L':th,'observed_episodes':len(episodes),'detected_episodes':detected,'episode_recall':detected/len(episodes) if episodes else np.nan,'median_warning_lead_hours':np.median(leads) if leads else np.nan})
pd.DataFrame(rows).to_csv(TAB/'R8_threshold_sensitivity_pointwise.csv',index=False)
pd.DataFrame(eps).to_csv(TAB/'R9_threshold_sensitivity_episodewise.csv',index=False)

# plots
# performance clean
rc=res[res.variant=='regularized_clean']
for metric,name in [('RMSE','RMSE'),('R2','R2')]:
 fig,axes=plt.subplots(1,2,figsize=(12,5),sharey=False)
 for ax,(river,g) in zip(axes,rc.groupby('river')):
  for model,m in g.groupby('model'): ax.plot(m.horizon_hours,m[metric],marker='o',label=model)
  ax.set_title(river);ax.set_xlabel('Forecast horizon (h)');ax.set_ylabel(name);ax.grid(alpha=.2)
 axes[0].legend(fontsize=7);fig.suptitle(f'Regularized clean-data model performance: {name}');fig.tight_layout();fig.savefig(FIG/f'R10_performance_{metric}.png',dpi=400,bbox_inches='tight');plt.close(fig)
# threshold xgb only
th=pd.DataFrame(rows); th=th[th.model=='XGBoost']
fig,axes=plt.subplots(1,2,figsize=(11,5),sharey=True)
for ax,(river,g) in zip(axes,th.groupby('river')):
 for threshold,m in g.groupby('threshold_mg_L'): ax.plot(m.horizon_hours,m.F1,marker='o',label=f'{threshold} mg/L')
 ax.set_title(river);ax.set_xlabel('Forecast horizon (h)');ax.set_ylabel('F1-score');ax.set_ylim(-.02,1.02);ax.grid(alpha=.2)
axes[0].legend();fig.suptitle('Threshold sensitivity of XGBoost low-DO screening');fig.tight_layout();fig.savefig(FIG/'R11_threshold_sensitivity_XGBoost_F1.png',dpi=400,bbox_inches='tight');plt.close(fig)

# Excel workbook
with pd.ExcelWriter(OUT/'Reviewer_Reanalysis_Tables.xlsx',engine='openpyxl') as w:
 pd.DataFrame(au).to_excel(w,sheet_name='timestamp_audit',index=False)
 pd.DataFrame(negatives).to_excel(w,sheet_name='negative_audit',index=False)
 res.to_excel(w,sheet_name='model_performance',index=False)
 pivot.to_excel(w,sheet_name='negative_sensitivity',index=False)
 pd.concat(shap_imp).to_excel(w,sheet_name='SHAP_importance',index=False)
 pd.DataFrame(rows).to_excel(w,sheet_name='threshold_pointwise',index=False)
 pd.DataFrame(eps).to_excel(w,sheet_name='threshold_episode',index=False)
# summary
summary={'timestamp_audit':au,'n_negative':len(negatives),'best_models_clean':rc.loc[rc.groupby(['river','horizon_hours']).RMSE.idxmin()][['river','horizon_hours','model','RMSE','R2']].to_dict('records'),'xgb24':res[(res.variant=='regularized_clean')&(res.horizon_hours==24)&(res.model=='XGBoost')].to_dict('records')}
(OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2,default=str))
# zip
with zipfile.ZipFile(ROOT/'Reviewer_Reanalysis_Complete.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.rglob('*'):
  if p.is_file(): z.write(p,p.relative_to(OUT))
print(pd.DataFrame(au).to_string(index=False))
print('\nXGB24\n',res[(res.variant=='regularized_clean')&(res.horizon_hours==24)&(res.model=='XGBoost')][['river','RMSE','MAE','R2','RMSE_CI_low','RMSE_CI_high']].to_string(index=False))
print('\nBest clean\n',rc.loc[rc.groupby(['river','horizon_hours']).RMSE.idxmin()][['river','horizon_hours','model','RMSE','R2']].to_string(index=False))
print('DONE',ROOT/'Reviewer_Reanalysis_Complete.zip')
