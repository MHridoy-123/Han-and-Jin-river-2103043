# Reviewer-requested re-analysis: multi-horizon dissolved oxygen forecasting

This repository package reproduces the reviewer-requested re-analysis for the Han and Jin River dissolved oxygen forecasting study.

## Analyses included

1. Exact 4-hour timestamp-grid reconstruction and temporal-gap audit
2. Causal predictor imputation
3. Cleaning and sensitivity analysis of physically impossible negative values
4. Multi-horizon forecasting at 4, 12, 24, 48, and 72 hours
5. Persistence and seasonal-persistence baselines
6. Autoregressive ridge, linear regression, random forest, and XGBoost
7. Block-bootstrap confidence intervals for RMSE
8. Unified 24-hour XGBoost and SHAP analysis
9. Point-wise and episode-wise low-DO sensitivity at 6, 5, and 4 mg/L

## Repository structure

```text
.
├── code/
│   └── reanalysis_pipeline.py
├── outputs/
│   ├── figures/
│   ├── processed/
│   ├── tables/
│   └── Reviewer_Reanalysis_Tables.xlsx
├── analysis_summary.json
├── requirements.txt
├── CITATION.cff
└── README.md
```

## Required input files

Place these two files in the repository root:

- `Dataset_WQ_Han_River.csv`
- `Dataset_WQ_Jin_River.csv`

Expected variables are date/Date, WT, pH, DO, CODMn, NH3-N, TP, TN, EC, and Turbidity.

## Installation and execution

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python code/reanalysis_pipeline.py
```

On Windows PowerShell, activate the environment with:

```powershell
.venv\Scripts\Activate.ps1
```

The pipeline reads the two CSV files from the repository root and writes regenerated results to `Reanalysis_Outputs/`.

## Key reproducibility decisions

- Missing timestamps were reconstructed on exact 4-hour grids.
- Predictor gaps were filled causally using forward filling for no more than 24 hours, followed by month-hour medians estimated from the 2021-2023 development period.
- Only genuinely observed DO targets were used for test evaluation.
- Negative CODMn, TP, and turbidity values were converted to missing in the primary cleaned workflow.
- A retained-negative 24-hour workflow was fitted for sensitivity comparison.
- The same cleaned 24-hour XGBoost models were used for performance evaluation and SHAP attribution.
- Random seeds are fixed at 2026 where stochastic algorithms are used.

## Main output files

- `outputs/tables/R1_timestamp_audit.csv`
- `outputs/tables/R2_negative_value_audit.csv`
- `outputs/tables/R3_full_model_performance_regularized_sensitivity.csv`
- `outputs/tables/R5_negative_cleaning_sensitivity.csv`
- `outputs/tables/R6_SHAP_importance_all_rivers_24h.csv`
- `outputs/tables/R7_unified_XGBoost_SHAP_metrics_24h.csv`
- `outputs/tables/R8_threshold_sensitivity_pointwise.csv`
- `outputs/tables/R9_threshold_sensitivity_episodewise.csv`
- `outputs/Reviewer_Reanalysis_Tables.xlsx`

## Data note

The raw CSV files are not redistributed in this package. Add the source files separately and cite the original dataset in the repository and associated manuscript.
