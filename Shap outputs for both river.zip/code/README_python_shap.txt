
# Standalone Python SHAP code for Han and Jin River water-quality data
# Requirements: pandas, numpy, matplotlib, scikit-learn, xgboost
# This delivered ZIP already contains generated outputs.
# If you want to reproduce, ask Copilot to provide the full standalone script.
